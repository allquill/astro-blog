---
title: Terms
description: The terms of using this site.
showInHeader: false
showInFooter: true
---
The content on this site is provided as is. Code samples are free to use in your own projects; please link back if you republish an article.
