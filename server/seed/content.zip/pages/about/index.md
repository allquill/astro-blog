---
title: About
description: Who writes this blog, and why.
showInHeader: true
showInFooter: true
---
**Acme Dev Blog** is written by the engineers at Acme. We write about the things we build and the mistakes we made building them, with code you can copy.

## Get in touch

Spotted a mistake, or want us to cover something? [Send us feedback](/feedback/), or e-mail blog@acme.example.

## Stay up to date

[Subscribe by e-mail](/subscribe/) to get one message per new post, or follow the [RSS feed](/rss.xml).
