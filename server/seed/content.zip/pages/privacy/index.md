---
title: Privacy
description: What we collect when you read, like, share, subscribe or send feedback, and why.
showInHeader: false
showInFooter: true
---
We keep as little as we can.

## Reading

Pages are static files. If you accept analytics cookies, Google Analytics records page views and a few events (such as share clicks and searches). If you decline, it records nothing that identifies you.

## Likes and share counts

When you like a post we store a salted, one-way hash of your IP address and browser, so the same visitor is only counted once. We never store the address itself. Share buttons only count the click; the share happens on the network you choose.

## Mailing list

We store your e-mail address, optional name and topic choices, and when you subscribed and confirmed. Every e-mail has a one-click unsubscribe link. Ask us at any time to delete your record.

## Feedback

We store what you send us. An e-mail address is optional and only used to reply.
